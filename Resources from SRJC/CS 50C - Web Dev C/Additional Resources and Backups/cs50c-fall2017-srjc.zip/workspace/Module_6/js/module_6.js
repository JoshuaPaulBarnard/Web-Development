// The Dialog Box for Winning
$(document).ready(function() {
    $("#WinDialog").dialog(
      {
          autoOpen: false
      }
    );
});

$(document).ready(function() {
    $("#about").accordion();
});
