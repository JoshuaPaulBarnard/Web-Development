<?php
// STEP 1: load header.php for theme using WP framework
get_header();
?>

<div class="container">
	<div class="page-header">
		<h1>Welcome to the site</h1>
	</div>
	
	<div class="panel-group">

<?php
// STEP 2: load post content for display from WP framework
// we use a PHP while loop together with the built-in
// WP function have_posts() to find out if there is content to show
// if we content, we then call the_post() to load content to display
while ( have_posts() ) : the_post();
?>

	<!-- the_title() prints out the current page title from WP framework -->
		<div class="col-xs-6 col-sm-4 col-md-3 col-lg-2">
			<div class="panel panel-default">
				<div class="panel-heading">
					<a href="<?php the_permalink(); ?>">
						<?php the_title(); ?>
					</a>
				</div>
				<div class="panel-body">
					<!-- the_post_thumbnail() prints out img element w featured image -->
					<?php the_post_thumbnail('medium'); ?>
					<!-- the_date() prints out the date the page was saved -->
					<p><?php the_date('Y-m-d', 'Published on '); ?></p>
					<!-- the_excerpt() prints out trimmed body field -->
					<p class="page-content"><?php the_excerpt(); ?></p>
					<!-- the_tags() prints out related tags for post -->
					<p class="page-tags"><?php the_tags(); ?></p>
				</div>
			</div>
		</div>

<?php
endwhile;
?>

<?php
// STEP 3: load page content for display from WP framework with query_posts()
// we use a PHP while loop together with the built-in
// WP function have_posts() to find out if there is content to show
// if we content, we then call the_post() to load content to display
query_posts( array('post_type' => 'page') );
while ( have_posts() ) : the_post();
?>

	<!-- the_title() prints out the current page title from WP framework -->
		<div class="col-xs-6 col-sm-4 col-md-3 col-lg-2">
			<div class="panel panel-default">
				<div class="panel-heading">
					<a href="<?php the_permalink(); ?>">
						<?php the_title(); ?>
					</a>
				</div>
				<div class="panel-body">
					<!-- the_post_thumbnail() prints out img element w featured image -->
					<?php the_post_thumbnail('medium'); ?>
					<!-- the_date() prints out the date the page was saved -->
					<p><?php the_date('Y-m-d', 'Published on '); ?></p>
					<!-- the_excerpt() prints out trimmed body field -->
					<p class="page-content"><?php the_excerpt(); ?></p>
					<!-- the_tags() prints out related tags for post -->
					<p class="page-tags"><?php the_tags(); ?></p>
				</div>
			</div>
		</div>

<?php
endwhile;
?>

	</div> <!-- closing tag for .panel-group -->
</div> <!-- closing tag for .container -->

<?php
// LAST STEP: load footer.php for theme using WP framework
get_footer();
?>