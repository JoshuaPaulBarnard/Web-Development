<!DOCTYPE html>
<html lang="en">
	<!-- header.php includes doctype, opening html tag
	     and ENTIRE head element (open + close) -->
<head>
	<!-- STEP 1: WP framework function bloginfo() 
		 * is built-in to WP, we get it for free!
		 * outputs page content for the current URL -->
	<title><?php bloginfo('title'); ?></title>

	<!-- STEP 2: WP framework function wp_head()
		 * outputs ALL html child elements the framework wants to include -->
<?php wp_head(); ?>
</head>
	<!-- header.php includes the OPENING body tag -->
<body>
	<nav class="navbar navbar-default">
		<div class="container-fluid">
			<!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<img id="logo" src="<?php echo get_template_directory_uri(); ?>/assets/logo.png" alt="Logo">
				</a>
		</div>

<!-- here let's use wp_nav_menu to output html for my Main Menu -->
<?php
wp_nav_menu( array(
	'menu'              => 'primary',
	'theme_location'    => 'primary',
	'depth'             => 2,
	'container'         => 'div',
	'container_class'   => 'collapse navbar-collapse',
	'container_id'      => 'bs-example-navbar-collapse-1',
	'menu_class'        => 'nav navbar-nav',
	'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
	'walker'            => new wp_bootstrap_navwalker())
);
?>
	</nav>
<!-- end header.php -->