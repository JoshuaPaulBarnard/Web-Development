<!-- start footer.php -->
	<div class="container">
		<footer>
			<div class="row">
			
<!-- NEXT WE OUTPUT OUR WP-POWERED FOOTER WIDGET -->
	<?php
		// to output a wp-powered widget, check to see if it is used by its id
		// with is_active_sidebar(), then output it with dynamic_sidebar()
		if ( is_active_sidebar('footer-widget') ) {
			dynamic_sidebar('footer-widget');
		}
	?>
			</div>
			<div class="row">
				<div class="xs-col-12">
					<p style="font-size:0.8em;text-align:center;">This WordPress theme was created by instructor Ethan Wilde for use with Computer Studies courses at Santa Rosa Junior College.<br>It includes the <a href="https://getbootstrap.com/" target="_blank">Bootstrap 3</a> framework from Twitter.</p>
				</div>
			</div>
		</footer>
	</div> <!-- closing tag for .container -->

<!-- STEP 1: WP framework wp_footer(); 
	 * lets WP insert any child elements into body it wants to -->

<?php wp_footer(); ?>

</body>
</html>