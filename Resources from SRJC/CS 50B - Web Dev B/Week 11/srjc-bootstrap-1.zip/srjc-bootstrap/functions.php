<?php

// WORDPRESS THEME FUNCTIONS FILE functions.php

/*
// Inside this file, we can interact with the WordPress API
// - code the WordPress developers wrote to allow us to
// customize the site in most details
*/

/*
// 
// 1) Load the shared php code for rendering a Bootstrap framework menu
// 
*/
require_once('wp_bootstrap_navwalker.php');

/*
// 
// 2) register the Bootstrap master LESS files for generation to CSS
//    by the WP-LESS plug-in
// 
//    it takes 2 steps to successfully add a menu to our theme
//    a. create a php function to register a menu with wordpress
*/
function srjc_load_styles() {
	/* our code calls a built-in wp function to register a css file to include
	// wp_enqueue_style() takes 2 parameters
	// 1 parameter: the id name for the css file to generate 
	// 2 parameter: the path to the source file
	*/
	wp_enqueue_style('bootstrap-main', get_stylesheet_directory_uri().'/bootstrap/less/bootstrap.less');
	wp_enqueue_style('bootstrap-theme', get_stylesheet_directory_uri().'/bootstrap/less/theme.less');
}
/* b. tell wordpress when the site loads, uses our menu function
	// here we use the built-in wp add_action() function
	// to connect our php function to run before theme is loaded
	// using the 'init' event it happens before any html is prepared
	// add_action() takes 2 parameters
	// 1 parameter: which WP event should our code run at (when will our code run)
	// 2 parameter: the name of my php function that should run at that event
*/
add_action('init', 'srjc_load_styles');


/*
//
// 3) load the jQuery JavaScript library file included with WordPress fileset
//    and the distribution file for bootstrap.js (including all bootstrap plugins)
//
//    it takes 2 steps to successfully add external scripts to our theme
//    a. create a php function to add external scripts with wordpress
*/
function srjc_load_scripts() {
	wp_enqueue_script( 'jquery' );
	wp_enqueue_script( 'bootstrap', get_stylesheet_directory_uri().'/bootstrap/dist/js/bootstrap.min.js');
}
// b. tell wp to run the script loading function before theme is loaded
add_action( 'init', 'srjc_load_scripts' );


/*
// 
// 4) add featured image support for our posts
// 
//    it takes 2 steps to successfully add featured image support
//    a. create a php function to enable the setting via wordpress api
*/
function srjc_enable_featured_image() {
	add_theme_support('post-thumbnails');
}
// b. tell wp to un the enable image function after theme is loaded
add_action('after_setup_theme','srjc_enable_featured_image');


/*
// 
// 5) add html5 support for our theme
// 
//    it takes 2 steps to successfully add html5 support
//    a. create a php function to enable the setting via wordpress api
*/
function srjc_enable_html5() {
	add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );
}
// b. tell wp to run the html5 function after theme is loaded
add_action('after_setup_theme','srjc_enable_html5');


/*
// 
// 6) add a menu
// 
//    it takes 2 steps to successfully add a menu to our theme
//    a. create a php function to register a menu with wordpress
*/
function srjc_register_menu() {
	/* our code calls a built-in wp function to define a menu
	// register_nav_menu() takes 2 parameters
	// 1 parameter: the id name for the menu
	// 2 parameter: the human-readable text name for the menu
	//              which gets passed to wp __() double underscore function
	*/
	register_nav_menu( 'primary', __('Primary Menu') );
}
// b. tell wp to run the menu function before theme is loaded
add_action('init','srjc_register_menu');

/*
// 
// 7) add a footer widgets area to our site
//
// it takes 2 steps to successfully add a widget (sidebar) to our theme
// a. create a php function to define a widget area with wordpress
*/
function srjc_register_widget() {
	/* our code calls a built-in wp function to define a widget area
	// register_sidebar() 
	// which takes a BUNCH of values to configure, delivered in a php array
	*/
	register_sidebar(
		array(
			'name' => __('Footer', 'srjc-bootstrap'),
			'id' => 'footer-widget',
			'before_widget' => '<div class="widget col-xs-6 col-sm-4 col-md-3 col-lg-2">',
			'after_widget' => '</div>',
			'before_title' => '<h5 class="title">',
			'after_title' => '</h5>'
		)
	);
}
// b. tell wp to run the widget function when initializing the site widgets
add_action('widgets_init','srjc_register_widget');

?>
