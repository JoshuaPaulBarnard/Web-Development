<?php
get_header();
?>

<div class="container">

<?php
	while ( have_posts() ) : the_post();
?>

	<div class="page-header">
		<h1><?php the_title(); ?></h1>
		<h5>Page</h5>
	</div>
	
	<div class="row">
		<?php the_content(); ?>
	</div>
	
<?php
	endwhile;
?>

</div> <!-- closing tag for .container -->

<?php
get_footer();
?>